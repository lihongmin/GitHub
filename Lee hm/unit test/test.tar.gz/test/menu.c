/**************************************************************************************************/
/* Copyright (C)  SSE@USTC, 2014-2015                                                             */
/*                                                                                                */
/*  FILE NAME             :  menu.c                                                               */
/*  PRINCIPAL AUTHOR      :  lihongmin                                                            */
/*  STUDENT NUMBER        :  JG14225081                                                           */
/*  SUBSYSTEM NAME        :  menu                                                                 */
/*  MODULE NAME           :  menu                                                                 */
/*  LANGUAGE              :  C                                                                    */
/*  TARGET ENVIRONMENT    :  ANY                                                                  */
/*  DATE OF FIRST RELEASE :  2014/09/13                                                           */
/*  DESCRIPTION           :  This is a menu program                                               */
/**************************************************************************************************/

/*
 * Revision log:
 *
 * Created by lihongmin, 2014/09/30
 *
 */
 
 
#include"menu.h"

/*
 * Find the Cmd
 */

tDataNode *FindCmd(tLinkTable * pLinkTable, char *cmd)
{
    if( pLinkTable == NULL|| cmd == NULL )
    {
        return (tDataNode *)FAILURE;
    }
    return (tDataNode *)SUCCESS;
}
/*
 * Show All Cmd
 */
int ShowAllCmd(tLinkTable * pLinkTable)
{
    if( pLinkTable == NULL )
    {
        return FAILURE;
    }
    return SUCCESS;
}
/*
 * Creat a Menu
 */
int CreatMenu(tLinkTable * pLinkTable, tDataNode* data, int n)
{
    if( pLinkTable == NULL|| data == NULL || n < 0)
    {
        return FAILURE;
    }
    return SUCCESS;
}
/*
 * Run the Menu
 */
int RunMenu(tLinkTable * pLinkTable)
{
    if( pLinkTable == NULL )
    {
        return FAILURE;
    }
    return SUCCESS;    
}
/*
 * Add a Cmd to Menu
 */
int Add(tLinkTable* pLinkTable)
{
    if( pLinkTable == NULL)
    {
        return FAILURE;
    }
    return SUCCESS;
}
/*
 * Delete a Cmd from Menu
 */
int Delete(tLinkTable* pLinkTable)
{
    if( pLinkTable == NULL )
    {
        return FAILURE;
    }
    return SUCCESS;
}
/*
 * Quit Menu
 */
int Quit(tLinkTable* pLinkTable)
{
    if( pLinkTable == NULL )
    {
        return FAILURE;
    }
    return SUCCESS;
}
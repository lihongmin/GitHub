/**************************************************************************************************/
/* Copyright (C)  SSE@USTC, 2014-2015                                                             */
/*                                                                                                */
/*  FILE NAME             :  menu.c                                                               */
/*  PRINCIPAL AUTHOR      :  lihongmin                                                            */
/*  STUDENT NUMBER        :  JG14225081                                                           */
/*  SUBSYSTEM NAME        :  menu                                                                 */
/*  MODULE NAME           :  menu                                                                 */
/*  LANGUAGE              :  C                                                                    */
/*  TARGET ENVIRONMENT    :  ANY                                                                  */
/*  DATE OF FIRST RELEASE :  2014/09/13                                                           */
/*  DESCRIPTION           :  This is a menu program                                               */
/**************************************************************************************************/

/*
 * Revision log:
 *
 * Created by lihongmin, 2014/09/30
 *
 */


#include<stdlib.h>

#define SUCCESS 1
#define FAILURE 0

typedef struct LinkTable 
{

}tLinkTable;
/*
 * Data Node Type
 */
typedef struct DataNode 
{

}tDataNode;
/*
 * Find the Cmd
 */
tDataNode *FindCmd(tLinkTable * pLinkTable, char *cmd);
/*
 * Show All Cmd
 */
int ShowAllCmd(tLinkTable * pLinkTable);
/*
 * Creat a Menu
 */
int CreatMenu(tLinkTable * pLinkTable, tDataNode* data, int n);
/*
 * Run the Menu
 */
int RunMenu(tLinkTable * pLinkTable);
/*
 * Add a Cmd to Menu
 */
int Add(tLinkTable* pLinkTable);
/*
 * Delete a Cmd from Menu
 */
int Delete(tLinkTable* pLinkTable);
/*
 * Quit Menu
 */
int Quit(tLinkTable* pLinkTable);